# -*- coding: utf-8 -*-
"""
Created on Sat Oct  5 18:27:01 2019

@author: wtomjack
"""
import pandas as pd
import numpy as np
from sklearn import preprocessing
from sklearn.metrics import accuracy_score, make_scorer
from sklearn.model_selection import validation_curve, train_test_split, learning_curve
from mlrose.neural import (gradient_descent, NetworkWeights, ContinuousOpt,
                           NeuralNetwork)
from mlrose.activation import identity, sigmoid, softmax
import time

class Experiment():

    def __init__(self):
        self.pullData()
        self.GeneticAlgorithmExperiment()
        self.RandomHillClimbExperiment()
        self.SimulatedAnnealingExperiment()

    def test(self, actualY, classificationResults):
        accuracy = accuracy_score(actualY, classificationResults)
        #_, train_scores, test_scores = learning_curve(learner,xTrain, yTrain, train_sizes=train_sizes)
        return accuracy

    def GeneticAlgorithmExperiment(self):
        start = time.time()
        self.GAnetwork = NeuralNetwork(hidden_nodes=[2], activation='identity',
        algorithm='genetic_alg',
        bias=False, is_classifier=True,
        learning_rate=1, clip_max=1,
        max_attempts=100)

        weights = np.array([1, 1, 1, 1, 1, 1, 1, 1, 1, 1,1,1,1,1,1,1,1,1,1,1,1,1,1,1])
        #SET WEIGHTS AS A FUNCTION
        self.GAnetwork.fit(self.wineTrainX, self.wineTrainY, init_weights=weights)
        end = time.time() - start
        print 'End Time: ' + str(end)
        trainPrediction = self.GAnetwork.predict(self.wineTrainX)
        testPrediction = self.GAnetwork.predict(self.wineTestX)
        print "GARESULTS: "
        print "Train"
        print (self.test(self.wineTrainY, trainPrediction))
        print "Test"
        print(self.test(self.wineTestY, testPrediction))

    def RandomHillClimbExperiment(self):
        start = time.time()
        self.RHCnetwork = NeuralNetwork(hidden_nodes=[2], activation='relu',
        algorithm='random_hill_climb',
        bias=False, is_classifier=True,
        learning_rate=1, clip_max=1,
        max_attempts=100)
        weights = np.array([1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,1,1,1,1,1,1,1,1,1,1,1])
        self.RHCnetwork.fit(self.wineTrainX, self.wineTrainY, init_weights=weights)
        end = time.time()-start
        print 'End Time: ' + str(end)
        trainPrediction = self.RHCnetwork.predict(self.wineTrainX)
        testPrediction = self.RHCnetwork.predict(self.wineTestX)
        print "RHCRESULTS: "
        print "Train"
        print (self.test(self.wineTrainY, trainPrediction))
        print "Test"
        print(self.test(self.wineTestY, testPrediction))

    def SimulatedAnnealingExperiment(self):
        start = time.time()
        self.SAnetwork = NeuralNetwork(hidden_nodes=[2], activation='relu',
        algorithm='simulated_annealing',
        bias=False, is_classifier=True,
        learning_rate=1, clip_max=1,
        max_attempts=100)
        weights = np.array([1, 1, 1, 1, 1, 1, 1, 1, 1, 1,1,1,1,1,1,1,1,1,1,1,1,1,1,1])
        self.SAnetwork.fit(self.wineTrainX, self.wineTrainY, init_weights=weights)
        end = time.time() - start
        print "End time: " + str(end)
        trainPrediction = self.SAnetwork.predict(self.wineTrainX)
        testPrediction = self.SAnetwork.predict(self.wineTestX)
        print "SARESULTS: "
        print "Train"
        print (self.test(self.wineTrainY, trainPrediction))
        print "Test"
        print(self.test(self.wineTestY, testPrediction))

    def pullData(self):
        #Wine Training and Testing Data
        wineData =pd.read_csv("Data/winequality-red.csv", sep=";")
        wineX = wineData.iloc[:,:-1]
        wineX = preprocessing.scale(wineX)
        wineY = wineData.iloc[:,-1]
        wineY.loc[(wineY.ix[:] == 1) | (wineY.ix[:] == 2) | (wineY.ix[:] == 3) | (wineY.ix[:] == 4) | (wineY.ix[:] == 5)] = 0
        wineY.loc[(wineY.ix[:] == 6) | (wineY.ix[:] == 7) | (wineY.ix[:] == 8) | (wineY.ix[:] == 9)] = 1
        self.wineTrainX, self.wineTestX, self.wineTrainY, self.wineTestY = train_test_split(wineX, wineY, test_size=.25, random_state=0)


