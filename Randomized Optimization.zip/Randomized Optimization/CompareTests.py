# -*- coding: utf-8 -*-
"""
Created on Wed Oct  2 18:10:44 2019

@author: wtomjack
"""
from mlrose import (random_hill_climb, simulated_annealing, genetic_alg, mimic, GeomDecay)
import time

class CompareTests():
    def __init__(self):
        pass

    def setProblem(self, problemSpace):
        self.knapsack = problemSpace.knapsackProblem
        self.fourpeaks = problemSpace.fourPeaksProblem
        self.countones = problemSpace.countOnesProblem

    def test(self):
        rhKS, rhFP, rhCO, rhKST, rhFPT, rhCOT = self.RandomHillClimbing()
        saKS, saFP, saCO, saKST, saFPT, saCOT = self.SimulatedAnnealing()
        gaKS, gaFP, gaCO, gaKST, gaFPT, gaCOT = self.GeneticAlgorithm()
        mKS, mFP, mCO, mKST, mFPT, mCOT = self.MIMIC()

        return rhKS, rhFP, rhCO, rhKST, rhFPT, rhCOT, saKS, saFP, saCO, saKST, saFPT, saCOT, \
        gaKS, gaFP, gaCO, gaKST, gaFPT, gaCOT, mKS, mFP, mCO, mKST, mFPT, mCOT

    def RandomHillClimbing(self):
        start = time.time()
        KSbest_state, KSbest_fitness, KScurve = random_hill_climb(self.knapsack, curve=True)
        rhKST = time.time() - start

        start = time.time()
        FPbest_state, FPbest_fitness, FPcurve = random_hill_climb(self.fourpeaks, curve =True)
        rhFPT = time.time() - start

        start = time.time()
        CObest_state, CObest_fitness, COcurve = random_hill_climb(self.countones, curve = True)
        rhCOT = time.time() - start

        return KSbest_fitness, FPbest_fitness, CObest_fitness, rhKST, rhFPT, rhCOT

    def SimulatedAnnealing(self):
        start = time.time()
        KSbest_state, KSbest_fitness, KScurve= simulated_annealing(self.knapsack, curve = True)
        saKST = time.time() - start

        start = time.time()
        FPbest_state, FPbest_fitness, FPcurve = simulated_annealing(self.fourpeaks, curve = True)
        saFPT = time.time() - start

        start = time.time()
        CObest_state, CObest_fitness, COcurve = simulated_annealing(self.countones, schedule=GeomDecay(init_temp=.01, decay=.99), curve = True)
        saCOT = time.time() - start

        return KSbest_fitness, FPbest_fitness, CObest_fitness, saKST, saFPT, saCOT

    def GeneticAlgorithm(self):
        start = time.time()
        KSbest_state, KSbest_fitness, KScurve= genetic_alg(self.knapsack, curve= True)
        gaKST = time.time() - start

        start = time.time()
        FPbest_state, FPbest_fitness, FPcurve = genetic_alg(self.fourpeaks, curve= True, max_attempts = 20, pop_size = 400)
        gaFPT = time.time() - start

        start = time.time()
        CObest_state, CObest_fitness, COcurve = genetic_alg(self.countones, curve = True)
        gaCOT = time.time() - start

        return KSbest_fitness, FPbest_fitness, CObest_fitness, gaKST, gaFPT, gaCOT

    def MIMIC(self):
       #start = time.time()
       # KSbest_state, KSbest_fitness, KScurve=  mimic(self.knapsack, pop_size= 99, curve = True)
       # mKST = time.time() - start

        start = time.time()
        FPbest_state, FPbest_fitness, FPcurve = mimic(self.fourpeaks, pop_size= 99, curve = True)
        mFPT = time.time() - start

        #start = time.time()
        #CObest_state, CObest_fitness, COcurve =  mimic(self.countones, pop_size= 99, curve = True)
        #mCOT = time.time() - start

        return 4, FPbest_fitness, 4, 4, mFPT,4
        #return KSbest_fitness, FPbest_fitness, CObest_fitness, mKST, mFPT, mCOT



